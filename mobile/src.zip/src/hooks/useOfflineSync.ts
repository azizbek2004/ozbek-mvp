import { useEffect, useRef } from "react";
import { useAppAuth } from "../providers/AuthProvider";
import { useOfflineStore } from "../stores/offlineStore";
import { useAuthStore } from "../stores/authStore";
import { getSyncQueue } from "../db/habitRepository";
import { getHabitsForDate, upsertLog } from "../services/firestoreService";
import { getToday } from "../utils/date";

export function useOfflineSync() {
  const { isAuthenticated, user } = useAppAuth();
  const isOnline = useOfflineStore((s) => s.isOnline);
  const userId = useAuthStore((s) => s.userId);
  const syncingRef = useRef(false);

  useEffect(() => {
    if (!isAuthenticated || !isOnline || !userId || !user?.uid) return;

    const uid = userId;
    const fireUid = user.uid;

    async function sync() {
      if (syncingRef.current) return;
      syncingRef.current = true;
      try {
        // Push pending offline operations to Firestore
        const queue = await getSyncQueue();
        const { setSyncing, setLastSynced, setPendingCount } =
          useOfflineStore.getState();

        setSyncing(true);

        type QueueItem = { id: number; operation: string; payload: string };
        for (const item of queue as QueueItem[]) {
          const payload = JSON.parse(item.payload);
          if (
            item.operation === "toggleHabit" ||
            item.operation === "incrementHabit"
          ) {
            try {
              await upsertLog({
                habitId: payload.habitId,
                userId: fireUid,
                logDate: payload.logDate,
                status: payload.status ?? "completed",
                value: payload.value ?? undefined,
              });
            } catch (e) {
              console.error("[sync] push error:", e);
            }
          }
        }

        // Pull latest data from Firestore into local SQLite
        try {
          const today = getToday();
          await getHabitsForDate(fireUid, today);
        } catch (e) {
          console.error("[sync] pull error:", e);
        }

        const remaining = await getSyncQueue();
        setPendingCount(remaining.length);
        setLastSynced(new Date().toISOString());
        setSyncing(false);
      } catch (error) {
        console.error("[sync] failed:", error);
      } finally {
        syncingRef.current = false;
      }
    }

    void sync();
  }, [isAuthenticated, isOnline, userId, user?.uid]);
}
