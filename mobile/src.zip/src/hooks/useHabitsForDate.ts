import { useCallback, useEffect, useState } from "react";
import { useAppAuth } from "../providers/AuthProvider";
import { useAuthStore } from "../stores/authStore";
import { useOfflineStore } from "../stores/offlineStore";
import {
  getHabitsForDate,
  upsertLog,
  type FireHabit,
  type FireHabitLog,
  type FireStreak,
} from "../services/firestoreService";
import {
  applyLocalToggle,
  applyLocalIncrement,
  getHabitsForDateLocal,
  type LocalHabit,
} from "../db/habitRepository";

export function useHabitsForDate(date: string) {
  const { isAuthenticated, user } = useAppAuth();
  const userId = useAuthStore((s) => s.userId);
  const isOnline = useOfflineStore((s) => s.isOnline);

  const [localHabits, setLocalHabits] = useState<LocalHabit[]>([]);
  const [localReady, setLocalReady] = useState(false);
  const [remoteHabits, setRemoteHabits] = useState<Array<
    FireHabit & {
      log?: FireHabitLog | null;
      streak?: FireStreak | null;
    }
  > | null>(null);

  const loadLocal = useCallback(async () => {
    if (!userId) {
      setLocalHabits([]);
      setLocalReady(true);
      return;
    }
    const rows = await getHabitsForDateLocal(userId, date);
    setLocalHabits(rows);
    setLocalReady(true);
  }, [userId, date]);

  const loadRemote = useCallback(async () => {
    if (!isAuthenticated || !user?.uid || !isOnline) return;
    try {
      const data = await getHabitsForDate(user.uid, date);
      setRemoteHabits(data);
    } catch (e) {
      console.error("[useHabitsForDate] remote fetch error:", e);
    }
  }, [isAuthenticated, user?.uid, isOnline, date]);

  useEffect(() => {
    void loadLocal();
  }, [loadLocal]);

  useEffect(() => {
    void loadRemote();
  }, [loadRemote]);

  useEffect(() => {
    if (remoteHabits && userId) {
      void loadLocal();
    }
  }, [remoteHabits, userId, loadLocal]);

  const habits: LocalHabit[] =
    isOnline && remoteHabits
      ? remoteHabits.map((h) => ({
          _id: h.id!,
          userId: userId!,
          name: h.name,
          nameRu: h.nameRu,
          icon: h.icon,
          color: h.color,
          type: h.type,
          targetType: h.targetType,
          targetValue: h.targetValue,
          frequencyType: h.frequencyType,
          timeOfDay: h.timeOfDay,
          reminderEnabled: h.reminderEnabled,
          sortOrder: h.sortOrder,
          isArchived: h.isArchived,
          log: h.log ? { status: h.log.status, value: h.log.value } : null,
          streak: h.streak
            ? {
                currentStreak: h.streak.currentStreak,
                bestStreak: h.streak.bestStreak,
                flexUsedThisMonth: h.streak.flexUsedThisMonth,
                lastCompletedDate: h.streak.lastCompletedDate,
              }
            : null,
        }))
      : localHabits;

  const isLoading =
    !localReady ||
    (isAuthenticated && isOnline && userId && remoteHabits === null);

  const toggleHabit = useCallback(
    async (habitId: string) => {
      if (!userId) return;
      const habit = habits.find((h) => h._id === habitId);
      const wasCompleted = habit?.log?.status === "completed";
      const newStatus = wasCompleted ? "missed" : "completed";

      // Apply locally
      await applyLocalToggle(userId, habitId, date, habit?.log ?? null);

      // Sync to Firestore if online
      if (isOnline && user?.uid) {
        try {
          await upsertLog({
            habitId,
            userId: user.uid,
            logDate: date,
            status: newStatus as "completed" | "missed",
          });
        } catch (e) {
          console.error("[useHabitsForDate] toggle sync error:", e);
        }
      }

      await loadLocal();
    },
    [habits, userId, date, loadLocal, isOnline, user?.uid]
  );

  const incrementHabit = useCallback(
    async (habitId: string, delta: number) => {
      if (!userId) return;
      const habit = habits.find((h) => h._id === habitId);
      if (!habit) return;
      const newValue = Math.max(0, (habit.log?.value ?? 0) + delta);
      const newStatus =
        newValue >= (habit.targetValue ?? 1) ? "completed" : "missed";

      await applyLocalIncrement(
        userId,
        habitId,
        date,
        delta,
        habit.log?.value ?? 0,
        habit.targetValue ?? 1
      );

      if (isOnline && user?.uid) {
        try {
          await upsertLog({
            habitId,
            userId: user.uid,
            logDate: date,
            status: newStatus as "completed" | "missed",
            value: newValue,
          });
        } catch (e) {
          console.error("[useHabitsForDate] increment sync error:", e);
        }
      }

      await loadLocal();
    },
    [habits, userId, date, loadLocal, isOnline, user?.uid]
  );

  return { habits, isLoading, toggleHabit, incrementHabit, refresh: loadLocal };
}
