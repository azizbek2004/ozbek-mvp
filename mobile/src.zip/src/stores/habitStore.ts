import { create } from "zustand";
import { getToday } from "../utils/date";

export interface HabitItem {
  id: string;
  serverId?: string;
  name: string;
  nameRu?: string;
  icon: string;
  color: string;
  type: string;
  targetType: string;
  targetValue?: number;
  frequencyType: string;
  timeOfDay: string;
  reminderEnabled: boolean;
  sortOrder: number;
  isArchived: boolean;
  log?: { status: string; value?: number } | null;
  streak?: { currentStreak: number; bestStreak: number; flexUsedThisMonth: number; lastCompletedDate?: string } | null;
}

interface HabitState {
  habits: HabitItem[];
  selectedDate: string;
  isLoading: boolean;
  setHabits: (habits: HabitItem[]) => void;
  addHabit: (habit: HabitItem) => void;
  updateHabitLog: (habitId: string, log: { status: string; value?: number }) => void;
  updateHabitStreak: (habitId: string, streak: NonNullable<HabitItem["streak"]>) => void;
  setSelectedDate: (date: string) => void;
  setLoading: (v: boolean) => void;
  removeHabit: (habitId: string) => void;
}

export const useHabitStore = create<HabitState>((set) => ({
  habits: [],
  selectedDate: getToday(),
  isLoading: true,

  setHabits: (habits) => set({ habits, isLoading: false }),
  addHabit: (habit) => set((s) => ({ habits: [...s.habits, habit] })),
  removeHabit: (habitId) => set((s) => ({ habits: s.habits.filter((h) => h.id !== habitId) })),

  updateHabitLog: (habitId, log) =>
    set((s) => ({
      habits: s.habits.map((h) => (h.id === habitId ? { ...h, log } : h)),
    })),

  updateHabitStreak: (habitId, streak) =>
    set((s) => ({
      habits: s.habits.map((h) => (h.id === habitId ? { ...h, streak } : h)),
    })),

  setSelectedDate: (date) => set({ selectedDate: date }),
  setLoading: (v) => set({ isLoading: v }),
}));
