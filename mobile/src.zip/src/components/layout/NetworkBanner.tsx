import React from "react";
import { View, Text, StyleSheet, ActivityIndicator } from "react-native";
import { Colors } from "../design-system/Colors";
import { Typography } from "../design-system/Typography";
import { Spacing } from "../design-system/Spacing";
import { useOfflineStore } from "../../stores/offlineStore";
import { useTranslation } from "react-i18next";

export function NetworkBanner() {
  const { isOnline, isSyncing, pendingCount } = useOfflineStore();
  const { t } = useTranslation();

  if (isSyncing) {
    return (
      <View style={[styles.banner, styles.syncBanner]}>
        <ActivityIndicator size="small" color={Colors.primary} />
        <Text style={styles.syncText}>{t("syncing")}</Text>
      </View>
    );
  }

  if (!isOnline) {
    return (
      <View style={styles.banner}>
        <Text style={styles.text}>
          📡 {t("noInternet")}. {t("dataSyncLater")}
          {pendingCount > 0 ? ` (${pendingCount} ${t("pendingOps")})` : ""}
        </Text>
      </View>
    );
  }

  if (pendingCount > 0) {
    return (
      <View style={[styles.banner, styles.pendingBanner]}>
        <Text style={styles.pendingText}>
          ⏳ {pendingCount} {t("pendingOps")}
        </Text>
      </View>
    );
  }

  return null;
}

const styles = StyleSheet.create({
  banner: {
    backgroundColor: Colors.warningLight,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.base,
    alignItems: "center",
  },
  syncBanner: {
    backgroundColor: Colors.primaryLight,
    flexDirection: "row",
    gap: Spacing.sm,
  },
  pendingBanner: { backgroundColor: Colors.surfaceElevated },
  text: { ...Typography.caption, color: Colors.warning },
  syncText: { ...Typography.caption, color: Colors.primary },
  pendingText: { ...Typography.caption, color: Colors.textSecondary },
});
