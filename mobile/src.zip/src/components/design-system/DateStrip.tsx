import React from "react";
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from "react-native";
import { Colors } from "./Colors";
import { Typography } from "./Typography";
import { Spacing } from "./Spacing";

interface DateItem {
  date: string;
  dayNumber: number;
  dayAbbr: string;
  isToday: boolean;
  hasCompletions?: boolean;
}

interface DateStripProps {
  dates: DateItem[];
  selectedDate: string;
  onSelectDate: (date: string) => void;
}

export function DateStrip({ dates, selectedDate, onSelectDate }: DateStripProps) {
  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.container}>
      {dates.map((item) => {
        const isSelected = item.date === selectedDate;
        const isToday = item.isToday;
        return (
          <TouchableOpacity key={item.date} onPress={() => onSelectDate(item.date)} style={styles.item}>
            <Text style={[styles.dayAbbr, isToday && styles.dayAbbrToday]}>{item.dayAbbr}</Text>
            <View style={[styles.circle, isSelected && styles.circleSelected, isToday && !isSelected && styles.circleToday]}>
              <Text style={[styles.dayNum, isSelected && styles.dayNumSelected, isToday && styles.dayNumToday]}>{item.dayNumber}</Text>
            </View>
            {item.hasCompletions && <View style={styles.completionDot} />}
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexDirection: "row", paddingHorizontal: Spacing.base, paddingVertical: Spacing.sm, gap: Spacing.sm },
  item: { alignItems: "center", width: 44 },
  dayAbbr: { ...Typography.caption, color: Colors.textSecondary, marginBottom: 4 },
  dayAbbrToday: { color: Colors.primary, fontWeight: "700" },
  circle: { width: 40, height: 40, borderRadius: 20, backgroundColor: Colors.surface, alignItems: "center", justifyContent: "center" },
  circleSelected: { backgroundColor: Colors.primary },
  circleToday: { borderWidth: 2, borderColor: Colors.primary },
  dayNum: { ...Typography.h3, color: Colors.textSecondary },
  dayNumSelected: { color: Colors.white },
  dayNumToday: { color: Colors.primary },
  completionDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.success, marginTop: 4 },
});
