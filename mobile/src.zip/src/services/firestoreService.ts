import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  addDoc,
  type Firestore,
} from "firebase/firestore";
import { getFirestoreDB } from "../lib/firebase";

// ─── Types ──────────────────────────────────────────────────────

export interface FireUser {
  userId: string;
  email: string;
  name: string;
  image?: string;
  language: string;
  theme: string;
  reminderEnabled: boolean;
  quietHoursStart: string;
  quietHoursEnd: string;
  createdAt: string;
}

export interface FireHabit {
  id?: string;
  userId: string;
  name: string;
  nameRu?: string;
  icon: string;
  color: string;
  type: string;
  targetType: string;
  targetValue?: number;
  frequencyType: string;
  timeOfDay: string;
  reminderEnabled: boolean;
  sortOrder: number;
  isArchived: boolean;
  createdAt: string;
}

export interface FireHabitLog {
  id?: string;
  habitId: string;
  userId: string;
  logDate: string;
  status: "completed" | "missed";
  value?: number;
  createdAt: string;
}

export interface FireStreak {
  id?: string;
  habitId: string;
  userId: string;
  currentStreak: number;
  bestStreak: number;
  flexUsedThisMonth: number;
  lastCompletedDate?: string;
}

export interface WeeklyStats {
  tartibScore: number;
  dailyRates: Array<{ dayName: string; rate: number }>;
  habitBreakdown: Array<{
    habitId: string;
    name: string;
    icon: string;
    color: string;
    completionRate: number;
  }>;
}

export interface MonthlyStats {
  tartibScore: number;
  weeklyRates: Array<{ week: number; rate: number }>;
  habitBreakdown: Array<{
    habitId: string;
    name: string;
    icon: string;
    color: string;
    completionRate: number;
  }>;
}

// ─── Collections ─────────────────────────────────────────────────

function getDb(): Firestore {
  return getFirestoreDB();
}

// ─── Users ───────────────────────────────────────────────────────

export async function syncUser(data: {
  userId: string;
  email: string;
  name: string;
  image?: string;
  language?: string;
}): Promise<void> {
  const db = getDb();
  const ref = doc(db, "users", data.userId);
  const snap = await getDoc(ref);

  const now = new Date().toISOString();

  if (snap.exists()) {
    await updateDoc(ref, {
      email: data.email,
      name: data.name,
      image: data.image ?? snap.data().image ?? "",
      language: data.language ?? snap.data().language ?? "uz",
      updatedAt: now,
    });
  } else {
    await setDoc(ref, {
      userId: data.userId,
      email: data.email,
      name: data.name,
      image: data.image ?? "",
      language: data.language ?? "uz",
      theme: "dark",
      reminderEnabled: true,
      quietHoursStart: "22:00",
      quietHoursEnd: "07:00",
      createdAt: now,
    });
  }
}

export async function getUser(userId: string): Promise<FireUser | null> {
  const db = getDb();
  const ref = doc(db, "users", userId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return null;
  return snap.data() as FireUser;
}

export async function updateUserProfile(
  userId: string,
  data: Partial<FireUser>
): Promise<void> {
  const db = getDb();
  const ref = doc(db, "users", userId);
  await updateDoc(ref, { ...data, updatedAt: new Date().toISOString() });
}

// ─── Habits ──────────────────────────────────────────────────────

export async function createHabit(
  data: Omit<FireHabit, "id" | "createdAt">
): Promise<string> {
  const db = getDb();
  const ref = await addDoc(collection(db, "habits"), {
    ...data,
    createdAt: new Date().toISOString(),
  });
  return ref.id;
}

export async function createBatchHabits(
  habits: Array<Omit<FireHabit, "id" | "createdAt">>
): Promise<string[]> {
  const db = getDb();
  const ids: string[] = [];

  for (const h of habits) {
    const ref = await addDoc(collection(db, "habits"), {
      ...h,
      createdAt: new Date().toISOString(),
    });
    ids.push(ref.id);
  }

  return ids;
}

export async function getHabitsForDate(
  userId: string,
  date: string
): Promise<
  Array<
    FireHabit & {
      log?: FireHabitLog | null;
      streak?: FireStreak | null;
    }
  >
> {
  const db = getDb();

  // Get habits
  const habitsQuery = query(
    collection(db, "habits"),
    where("userId", "==", userId),
    where("isArchived", "==", false),
    orderBy("sortOrder")
  );
  const habitSnap = await getDocs(habitsQuery);
  const habits = habitSnap.docs.map((d) => ({
    ...(d.data() as FireHabit),
    id: d.id,
  }));

  // Get logs for date
  const logsQuery = query(
    collection(db, "habitLogs"),
    where("userId", "==", userId),
    where("logDate", "==", date)
  );
  const logSnap = await getDocs(logsQuery);
  const logMap = new Map<string, FireHabitLog>();
  logSnap.docs.forEach((d) => {
    const log = d.data() as FireHabitLog;
    logMap.set(log.habitId, { ...log, id: d.id });
  });

  // Get streaks
  const streakQuery = query(
    collection(db, "streaks"),
    where("userId", "==", userId)
  );
  const streakSnap = await getDocs(streakQuery);
  const streakMap = new Map<string, FireStreak>();
  streakSnap.docs.forEach((d) => {
    const s = d.data() as FireStreak;
    streakMap.set(s.habitId, { ...s, id: d.id });
  });

  return habits.map((h) => ({
    ...h,
    log: logMap.get(h.id!) ?? null,
    streak: streakMap.get(h.id!) ?? null,
  }));
}

export async function updateHabit(
  habitId: string,
  data: Partial<FireHabit>
): Promise<void> {
  const db = getDb();
  const ref = doc(db, "habits", habitId);
  await updateDoc(ref, data);
}

export async function deleteHabit(habitId: string): Promise<void> {
  const db = getDb();
  await deleteDoc(doc(db, "habits", habitId));
}

// ─── Habit Logs ──────────────────────────────────────────────────

export async function upsertLog(data: {
  habitId: string;
  userId: string;
  logDate: string;
  status: "completed" | "missed";
  value?: number;
}): Promise<void> {
  const db = getDb();
  const logId = `${data.habitId}_${data.logDate}`;
  const ref = doc(db, "habitLogs", logId);

  const snap = await getDoc(ref);
  if (snap.exists()) {
    await updateDoc(ref, { status: data.status, value: data.value ?? null });
  } else {
    await setDoc(ref, {
      ...data,
      id: logId,
      createdAt: new Date().toISOString(),
    });
  }

  // Update streak after log change
  await recalculateStreak(data.habitId, data.userId);
}

async function recalculateStreak(
  habitId: string,
  userId: string
): Promise<void> {
  const db = getDb();

  // Get last 90 days of logs
  const logsQuery = query(
    collection(db, "habitLogs"),
    where("habitId", "==", habitId),
    orderBy("logDate", "desc")
  );
  const logSnap = await getDocs(logsQuery);
  const logs = logSnap.docs.map((d) => d.data() as FireHabitLog);

  let currentStreak = 0;
  let bestStreak = 0;
  let flexUsedThisMonth = 0;
  let lastCompletedDate: string | undefined;

  // Calculate streaks from logs
  // Sort by date descending
  const sorted = [...logs].sort(
    (a, b) => new Date(b.logDate).getTime() - new Date(a.logDate).getTime()
  );

  for (const log of sorted) {
    if (log.status === "completed") {
      currentStreak++;
      if (!lastCompletedDate) lastCompletedDate = log.logDate;
    } else {
      if (currentStreak > bestStreak) bestStreak = currentStreak;
      currentStreak = 0;
    }
  }
  if (currentStreak > bestStreak) bestStreak = currentStreak;

  const streakId = `streak_${habitId}`;
  const streakRef = doc(db, "streaks", streakId);
  const streakSnap = await getDoc(streakRef);

  const streakData: FireStreak = {
    habitId,
    userId,
    currentStreak,
    bestStreak,
    flexUsedThisMonth,
    lastCompletedDate,
  };

  if (streakSnap.exists()) {
    await updateDoc(streakRef, streakData as Record<string, any>);
  } else {
    await setDoc(streakRef, { ...streakData, id: streakId });
  }
}

// ─── Stats ───────────────────────────────────────────────────────

export async function getWeeklyStats(
  userId: string,
  startDate: string,
  endDate: string
): Promise<WeeklyStats> {
  const db = getDb();
  const habits = await getHabitsForDate(userId, startDate);

  const dayNames = ["Du", "Se", "Ch", "Pa", "Ju", "Sh", "Ya"];
  const dailyRates: Array<{ dayName: string; rate: number }> = [];
  const habitBreakdown: WeeklyStats["habitBreakdown"] = [];

  const start = new Date(startDate);
  const end = new Date(endDate);

  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    const dateStr = d.toISOString().split("T")[0];
    const logsQuery = query(
      collection(db, "habitLogs"),
      where("userId", "==", userId),
      where("logDate", "==", dateStr)
    );
    const logSnap = await getDocs(logsQuery);
    const logs = logSnap.docs.map((l) => l.data() as FireHabitLog);
    const completed = logs.filter((l) => l.status === "completed").length;
    const rate =
      logs.length > 0 ? Math.round((completed / logs.length) * 100) : 0;
    dailyRates.push({ dayName: dayNames[d.getDay()], rate });
  }

  // Habit breakdown
  for (const habit of habits) {
    const logsQuery = query(
      collection(db, "habitLogs"),
      where("habitId", "==", habit.id),
      where("logDate", ">=", startDate),
      where("logDate", "<=", endDate)
    );
    const logSnap = await getDocs(logsQuery);
    const logs = logSnap.docs.map((l) => l.data() as FireHabitLog);
    const completed = logs.filter((l) => l.status === "completed").length;
    const rate =
      logs.length > 0 ? Math.round((completed / logs.length) * 100) : 0;
    habitBreakdown.push({
      habitId: habit.id!,
      name: habit.name,
      icon: habit.icon,
      color: habit.color,
      completionRate: rate,
    });
  }

  const totalRate = dailyRates.reduce((s, d) => s + d.rate, 0);
  const tartibScore =
    dailyRates.length > 0 ? Math.round(totalRate / dailyRates.length) : 0;

  return { tartibScore, dailyRates, habitBreakdown };
}

export async function getMonthlyStats(
  userId: string,
  year: number,
  month: number
): Promise<MonthlyStats> {
  const db = getDb();
  const habits = await getHabitsForDate(
    userId,
    `${year}-${String(month).padStart(2, "0")}-01`
  );

  const weeksInMonth = 4;
  const weeklyRates: Array<{ week: number; rate: number }> = [];
  const habitBreakdown: MonthlyStats["habitBreakdown"] = [];
  const monthStr = `${year}-${String(month).padStart(2, "0")}`;

  for (let w = 1; w <= weeksInMonth; w++) {
    const startDay = (w - 1) * 7 + 1;
    const endDay = Math.min(w * 7, new Date(year, month, 0).getDate());
    let totalLogs = 0;
    let totalCompleted = 0;

    for (let d = startDay; d <= endDay; d++) {
      const dateStr = `${monthStr}-${String(d).padStart(2, "0")}`;
      const logsQuery = query(
        collection(db, "habitLogs"),
        where("userId", "==", userId),
        where("logDate", "==", dateStr)
      );
      const logSnap = await getDocs(logsQuery);
      const logs = logSnap.docs.map((l) => l.data() as FireHabitLog);
      totalLogs += logs.length;
      totalCompleted += logs.filter((l) => l.status === "completed").length;
    }

    const rate =
      totalLogs > 0 ? Math.round((totalCompleted / totalLogs) * 100) : 0;
    weeklyRates.push({ week: w, rate });
  }

  for (const habit of habits) {
    const logsQuery = query(
      collection(db, "habitLogs"),
      where("habitId", "==", habit.id),
      where("logDate", ">=", `${monthStr}-01`),
      where(
        "logDate",
        "<=",
        `${monthStr}-${new Date(year, month, 0).getDate()}`
      )
    );
    const logSnap = await getDocs(logsQuery);
    const logs = logSnap.docs.map((l) => l.data() as FireHabitLog);
    const completed = logs.filter((l) => l.status === "completed").length;
    const rate =
      logs.length > 0 ? Math.round((completed / logs.length) * 100) : 0;
    habitBreakdown.push({
      habitId: habit.id!,
      name: habit.name,
      icon: habit.icon,
      color: habit.color,
      completionRate: rate,
    });
  }

  const totalRate = weeklyRates.reduce((s, w) => s + w.rate, 0);
  const tartibScore =
    weeklyRates.length > 0 ? Math.round(totalRate / weeklyRates.length) : 0;

  return { tartibScore, weeklyRates, habitBreakdown };
}

// ─── Delete Account ──────────────────────────────────────────────

export async function deleteUserAccount(userId: string): Promise<void> {
  const db = getDb();

  // Delete habits
  const habitsQuery = query(
    collection(db, "habits"),
    where("userId", "==", userId)
  );
  const habitSnap = await getDocs(habitsQuery);
  for (const h of habitSnap.docs) {
    await deleteDoc(h.ref);
  }

  // Delete logs
  const logsQuery = query(
    collection(db, "habitLogs"),
    where("userId", "==", userId)
  );
  const logSnap = await getDocs(logsQuery);
  for (const l of logSnap.docs) {
    await deleteDoc(l.ref);
  }

  // Delete streaks
  const streakQuery = query(
    collection(db, "streaks"),
    where("userId", "==", userId)
  );
  const streakSnap = await getDocs(streakQuery);
  for (const s of streakSnap.docs) {
    await deleteDoc(s.ref);
  }

  // Delete user doc
  await deleteDoc(doc(db, "users", userId));
}
