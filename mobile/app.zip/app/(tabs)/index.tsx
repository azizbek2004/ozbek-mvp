import React, { useMemo } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { SafeAreaView } from "react-native-safe-area-context";
import { Colors } from "../../src/components/design-system/Colors";
import { Typography } from "../../src/components/design-system/Typography";
import { Spacing } from "../../src/components/design-system/Spacing";
import { DateStrip } from "../../src/components/design-system/DateStrip";
import { HabitCard } from "../../src/components/design-system/HabitCard";
import { EmptyState } from "../../src/components/feedback/EmptyState";
import { NetworkBanner } from "../../src/components/layout/NetworkBanner";
import { useHabitStore } from "../../src/stores/habitStore";
import { useLayout } from "../../src/hooks/useLayout";
import { useHabitsForDate } from "../../src/hooks/useHabitsForDate";
import { getWeekDates, formatUzbekDate } from "../../src/utils/date";
import { TIME_OF_DAY } from "../../src/utils/constants";

export default function HomeScreen() {
  const router = useRouter();
  const { t } = useTranslation();
  const { selectedDate, setSelectedDate } = useHabitStore();
  const { horizontalPadding, contentMaxWidth, tabBarHeight } = useLayout();
  const weekDates = useMemo(() => getWeekDates(new Date()), []);
  const todayFormatted = formatUzbekDate(new Date());

  const { habits, isLoading, toggleHabit, incrementHabit } =
    useHabitsForDate(selectedDate);

  const grouped = useMemo(() => {
    const groups: Record<string, typeof habits> = {
      morning: [],
      afternoon: [],
      evening: [],
      all_day: [],
    };
    habits.forEach((h) => {
      const key = h.timeOfDay || "all_day";
      if (groups[key]) groups[key].push(h);
    });
    return Object.entries(groups).filter(([, items]) => items.length > 0);
  }, [habits]);

  const totalStreak = habits.reduce(
    (sum, h) => sum + (h.streak?.currentStreak || 0),
    0
  );

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container} edges={["top"]}>
        <View style={styles.loader}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <NetworkBanner />

      <View
        style={[
          styles.header,
          {
            paddingHorizontal: horizontalPadding,
            maxWidth: contentMaxWidth,
            alignSelf: "center",
            width: "100%",
          },
        ]}
      >
        <TouchableOpacity
          onPress={() => router.push("/(tabs)/profile")}
          style={styles.headerBtn}
        >
          <Text style={styles.headerIcon}>⚙️</Text>
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle}>{t("today")}</Text>
          <Text style={styles.headerDate}>{todayFormatted}</Text>
        </View>
        <View style={styles.streakBadge}>
          <Text style={styles.streakIcon}>🔥</Text>
          <Text style={styles.streakCount}>{totalStreak}</Text>
        </View>
      </View>

      <DateStrip
        dates={weekDates}
        selectedDate={selectedDate}
        onSelectDate={setSelectedDate}
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingHorizontal: horizontalPadding,
            paddingBottom: tabBarHeight + Spacing.lg,
            maxWidth: contentMaxWidth,
            alignSelf: "center",
            width: "100%",
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {grouped.length === 0 ? (
          <EmptyState
            icon="🧘"
            title={t("noHabitsToday")}
            subtitle={t("noHabitsSubtitle")}
            actionLabel={t("addFirstHabit")}
            onAction={() => router.push("/habit/new")}
          />
        ) : (
          grouped.map(([timeKey, items]) => {
            const config = TIME_OF_DAY[timeKey as keyof typeof TIME_OF_DAY];
            return (
              <View key={timeKey} style={styles.section}>
                <View style={styles.sectionHeader}>
                  <Text style={styles.sectionEmoji}>{config?.icon || "🕐"}</Text>
                  <Text style={styles.sectionTitle}>
                    {config?.labelUz || timeKey}
                  </Text>
                  {config?.range ? (
                    <Text style={styles.sectionRange}>{config.range}</Text>
                  ) : null}
                </View>
                {items.map((habit) => (
                  <HabitCard
                    key={habit._id}
                    name={habit.name}
                    icon={habit.icon}
                    color={habit.color}
                    targetType={habit.targetType}
                    targetValue={habit.targetValue}
                    log={habit.log}
                    streak={habit.streak}
                    completedLabel={t("completed")}
                    subtitle={
                      habit.targetType === "duration"
                        ? `${habit.targetValue || 0} ${t("minutes")}`
                        : habit.targetType === "count"
                          ? `${habit.log?.value ?? 0}/${habit.targetValue} ${habit.name === "Suv ichish" ? t("glasses") : ""}`
                          : undefined
                    }
                    onPress={() => void toggleHabit(habit._id)}
                    onIncrement={
                      habit.targetType === "count"
                        ? () => void incrementHabit(habit._id, 1)
                        : undefined
                    }
                    onDecrement={
                      habit.targetType === "count"
                        ? () => void incrementHabit(habit._id, -1)
                        : undefined
                    }
                  />
                ))}
              </View>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  loader: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: Spacing.sm,
    paddingBottom: Spacing.xs,
  },
  headerBtn: { minWidth: 48, minHeight: 48, alignItems: "center", justifyContent: "center" },
  headerIcon: { fontSize: 22 },
  headerCenter: { alignItems: "center", flex: 1 },
  headerTitle: { ...Typography.h1, color: Colors.textPrimary },
  headerDate: { ...Typography.caption, color: Colors.textSecondary, marginTop: 2 },
  streakBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surface,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  streakIcon: { fontSize: 16, marginRight: 4 },
  streakCount: { ...Typography.h3, color: Colors.warning },
  scroll: { flex: 1 },
  scrollContent: {},
  section: { marginTop: Spacing.lg },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.sm,
    gap: Spacing.xs,
    flexWrap: "wrap",
  },
  sectionEmoji: { fontSize: 16 },
  sectionTitle: { ...Typography.h2, color: Colors.textPrimary },
  sectionRange: { ...Typography.caption, color: Colors.textTertiary, marginLeft: Spacing.sm },
});
